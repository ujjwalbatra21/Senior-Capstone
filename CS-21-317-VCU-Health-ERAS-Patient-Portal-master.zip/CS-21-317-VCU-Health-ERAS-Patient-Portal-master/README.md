
# *VCU Health ERAS Patient Portal*
## *VCU Health / VCU college of Engineering *
## *Short Project Description*
Our goal with this project is to create an application for patients and healthcare workers as a guide for a patients’ pre/post op surgery. An application that is easy to navigate and access for patients to help with some of the stress they feel near their surgery and by including checklists, reminders, and basic procedure information about their surgery. We aim to help patients by providing an organized and easy place to go to for information in the form of this application.​


![GettingStarted](https://user-images.githubusercontent.com/43419166/117341006-99362f00-ae6f-11eb-9579-91eb005ce034.png)
![PatientChecklist](https://user-images.githubusercontent.com/43419166/117341016-9cc9b600-ae6f-11eb-9dcc-c06182a5a810.png)
![Instructions](https://user-images.githubusercontent.com/43419166/117341253-e5816f00-ae6f-11eb-80f3-80a73db43b02.png)




| Folder | Description |
|---|---|
| Documentation |  all documentation the project team has created to describe the architecture, design, installation and configuratin of the peoject |
| Notes and Research | Relavent information useful to understand the tools and techniques used in the project |
| Status Reports | Project management documentation - weekly reports, milestones, etc. |
| scr | Source code - create as many subdirectories as needed |

## Project Team
- *Paula Spencer*  - *VCU Health Office of Clinical Effectiveness* - Mentor
- *Robert Dalhberg* - *CS* - Faculty Advisor
- *Ujjwal Batra* - *CS* - Student Team Member
- *Anthony Cantarelli* - *CS* - Student Team Member
- *Roselyn Afarnu* - *CS* - Student Team Member
- *Stephen Kalen* - *CS* - Student Team Member



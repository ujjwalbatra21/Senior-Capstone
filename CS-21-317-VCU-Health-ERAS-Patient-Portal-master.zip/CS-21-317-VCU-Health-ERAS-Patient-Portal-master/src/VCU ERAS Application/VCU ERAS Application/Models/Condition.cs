﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VCU_ERAS_Application.Models
{
    public class Condition
    {
        public string conditionname { get; set; }
        public string dietinstructions { get; set; }
        public string postinstructions { get; set; }
    }
}

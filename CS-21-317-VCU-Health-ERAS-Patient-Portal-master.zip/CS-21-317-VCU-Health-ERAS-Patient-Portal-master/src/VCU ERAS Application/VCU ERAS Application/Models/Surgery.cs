﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VCU_ERAS_Application.Models
{
    public class Surgery
    {
        public string surgeryname { get; set; }
        public string surgeryInfo { get; set; }
    }
}

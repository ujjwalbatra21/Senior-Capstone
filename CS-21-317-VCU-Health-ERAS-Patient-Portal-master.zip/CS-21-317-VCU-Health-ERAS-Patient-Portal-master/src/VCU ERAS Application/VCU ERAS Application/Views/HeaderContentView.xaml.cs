﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace VCU_ERAS_Application
{
    public partial class HeaderContentView : ContentView
    {
        public HeaderContentView()
        {
            InitializeComponent();
        }
    }
}

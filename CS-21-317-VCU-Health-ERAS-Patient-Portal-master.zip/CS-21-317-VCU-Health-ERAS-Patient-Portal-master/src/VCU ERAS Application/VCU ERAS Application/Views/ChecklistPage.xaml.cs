﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace VCU_ERAS_Application.Views
{
    public partial class ChecklistPage : ContentPage
    {
        public ChecklistPage()
        {
            InitializeComponent();
        }
    }
}
